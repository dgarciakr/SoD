# -*- coding: utf-8 -*-


from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('mainsite', '0005_auto_20170427_0724'),
        ('mainsite', '0005_auto_20170616_1406'),
    ]

    operations = [
    ]
