default_app_config = 'badgeuser.apps.BadgeUserConfig'
