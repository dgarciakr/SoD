# -*- coding: utf-8 -*-


from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('badgeuser', '0003_auto_20160210_0313'),
        ('badgeuser', '0003_auto_20160309_0820'),
    ]

    operations = [
    ]
