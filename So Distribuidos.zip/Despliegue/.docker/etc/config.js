window.config = {
    api: {
        baseUrl: "http://nginx:443"
    }
}
