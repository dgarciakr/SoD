# -*- coding: utf-8 -*-


from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('issuer', '0021_remove_badgeinstance_evidence_url'),
        ('issuer', '0021_auto_20170424_1427'),
    ]

    operations = [
    ]
