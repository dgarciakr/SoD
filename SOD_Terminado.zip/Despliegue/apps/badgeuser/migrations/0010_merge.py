# -*- coding: utf-8 -*-


from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('badgeuser', '0007_auto_20170427_0724'),
        ('badgeuser', '0009_auto_20170427_1509'),
    ]

    operations = [
    ]
